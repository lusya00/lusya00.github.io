import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 1280;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // frame1VeW (19:3)
        width: double.infinity,
        decoration: BoxDecoration (
          border: Border.all(color: Color(0x19000000)),
          color: Color(0xffe5e5e5),
          borderRadius: BorderRadius.circular(2*fem),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // macbookair1Mq8 (1:2)
              width: double.infinity,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroupy32xUuk (7wpw69wpwPadPCJhRjy32X)
                    width: double.infinity,
                    height: 117*fem,
                    child: Stack(
                      children: [
                        Positioned(
                          // rectangle2NES (5:15)
                          left: 1051*fem,
                          top: 13*fem,
                          child: Align(
                            child: SizedBox(
                              width: 205*fem,
                              height: 44*fem,
                              child: Container(
                                decoration: BoxDecoration (
                                  color: Color(0xffd9d9d9),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // rectangle1tc6 (5:3)
                          left: 0*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 1280*fem,
                              height: 117*fem,
                              child: Container(
                                decoration: BoxDecoration (
                                  color: Color(0xfffdce0f),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // luscious1bmQ (5:4)
                          left: 71*fem,
                          top: 2*fem,
                          child: Align(
                            child: SizedBox(
                              width: 195*fem,
                              height: 115*fem,
                              child: Image.asset(
                                'assets/page-1/images/luscious-1.png',
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // hometVc (5:5)
                          left: 438*fem,
                          top: 42*fem,
                          child: Align(
                            child: SizedBox(
                              width: 70*fem,
                              height: 30*fem,
                              child: Text(
                                'Home',
                                style: SafeGoogleFont (
                                  'Inter',
                                  fontSize: 24*ffem,
                                  fontWeight: FontWeight.w800,
                                  height: 1.2125*ffem/fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // kulinerwTt (5:7)
                          left: 603*fem,
                          top: 42*fem,
                          child: Align(
                            child: SizedBox(
                              width: 85*fem,
                              height: 30*fem,
                              child: Text(
                                'Kuliner',
                                style: SafeGoogleFont (
                                  'Inter',
                                  fontSize: 24*ffem,
                                  fontWeight: FontWeight.w800,
                                  height: 1.2125*ffem/fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // tutorialNp6 (5:8)
                          left: 755*fem,
                          top: 44*fem,
                          child: Align(
                            child: SizedBox(
                              width: 92*fem,
                              height: 30*fem,
                              child: Text(
                                'Tutorial',
                                style: SafeGoogleFont (
                                  'Inter',
                                  fontSize: 24*ffem,
                                  fontWeight: FontWeight.w800,
                                  height: 1.2125*ffem/fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // contact4gv (5:11)
                          left: 901*fem,
                          top: 43*fem,
                          child: Align(
                            child: SizedBox(
                              width: 96*fem,
                              height: 30*fem,
                              child: Text(
                                'Contact',
                                style: SafeGoogleFont (
                                  'Inter',
                                  fontSize: 24*ffem,
                                  fontWeight: FontWeight.w800,
                                  height: 1.2125*ffem/fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // rectangle3xXQ (5:18)
                          left: 1034*fem,
                          top: 43*fem,
                          child: Align(
                            child: SizedBox(
                              width: 231*fem,
                              height: 39*fem,
                              child: Container(
                                decoration: BoxDecoration (
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // maumasakantradisionalaparsg (5:19)
                          left: 1051*fem,
                          top: 55*fem,
                          child: Align(
                            child: SizedBox(
                              width: 173*fem,
                              height: 15*fem,
                              child: Text(
                                'Mau masakan tradisional apa?',
                                style: SafeGoogleFont (
                                  'Inter',
                                  fontSize: 12*ffem,
                                  fontWeight: FontWeight.w500,
                                  height: 1.2125*ffem/fem,
                                  color: Color(0xffa29c9c),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // iconmagnifyingglasswPL (5:14)
                          left: 1235*fem,
                          top: 55*fem,
                          child: Align(
                            child: SizedBox(
                              width: 14*fem,
                              height: 14*fem,
                              child: Image.asset(
                                'assets/page-1/images/icon-magnifying-glass.png',
                                width: 14*fem,
                                height: 14*fem,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupzytuCKG (7wpwqYsBnU7HWHoBQDzyTu)
                    width: double.infinity,
                    height: 715*fem,
                    child: Stack(
                      children: [
                        Positioned(
                          // masakanindonesiafeatured212892 (5:20)
                          left: 0*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 1280*fem,
                              height: 715*fem,
                              child: Image.asset(
                                'assets/page-1/images/masakan-indonesia-featured-212892-1.png',
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // rectangle4QAS (5:23)
                          left: 363*fem,
                          top: 115*fem,
                          child: Align(
                            child: SizedBox(
                              width: 477*fem,
                              height: 114*fem,
                              child: Container(
                                decoration: BoxDecoration (
                                  color: Color(0xfffdce0f),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // welcometo7ae (5:24)
                          left: 426*fem,
                          top: 136*fem,
                          child: Align(
                            child: SizedBox(
                              width: 352*fem,
                              height: 73*fem,
                              child: Text(
                                'Welcome to',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont (
                                  'Inter',
                                  fontSize: 60*ffem,
                                  fontWeight: FontWeight.w800,
                                  height: 1.2125*ffem/fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // rectangle5Qpe (5:25)
                          left: 247*fem,
                          top: 269*fem,
                          child: Align(
                            child: SizedBox(
                              width: 711*fem,
                              height: 132*fem,
                              child: Container(
                                decoration: BoxDecoration (
                                  color: Color(0xfffdce0f),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // lusciousnusantaraLTQ (5:26)
                          left: 306*fem,
                          top: 299*fem,
                          child: Align(
                            child: SizedBox(
                              width: 591*fem,
                              height: 73*fem,
                              child: Text(
                                'Luscious Nusantara',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont (
                                  'Inter',
                                  fontSize: 60*ffem,
                                  fontWeight: FontWeight.w800,
                                  height: 1.2125*ffem/fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // temukanmasakantradisionalnusan (5:27)
                          left: 209*fem,
                          top: 461*fem,
                          child: Align(
                            child: SizedBox(
                              width: 780*fem,
                              height: 97*fem,
                              child: Text(
                                'Temukan masakan tradisional nusantara yang unik dan coba untuk membuatnya!',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont (
                                  'Inter',
                                  fontSize: 40*ffem,
                                  fontWeight: FontWeight.w600,
                                  height: 1.2125*ffem/fem,
                                  color: Color(0xffa29c9c),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // macbookair23FL (1:5)
              padding: EdgeInsets.fromLTRB(67*fem, 34*fem, 111.5*fem, 7*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
                image: DecorationImage (
                  fit: BoxFit.cover,
                  image: AssetImage (
                    'assets/page-1/images/masakan-indonesia-featured-212892-2-bg.png',
                  ),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // apakahkamutahubanyaklohmakanan (6:30)
                    margin: EdgeInsets.fromLTRB(43.5*fem, 0*fem, 0*fem, 16*fem),
                    constraints: BoxConstraints (
                      maxWidth: 1003*fem,
                    ),
                    child: Text(
                      'Apakah kamu tahu banyak loh makanan tradisional nusantara yang enak banget!!Yuk coba kita jelajahi?',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 40*ffem,
                        fontWeight: FontWeight.w600,
                        height: 1.2125*ffem/fem,
                        color: Color(0xff000000),
                      ),
                    ),
                  ),
                  Container(
                    // autogroupryxm78i (7wpy8gNfkP32ggSU71ryXm)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 15*fem),
                    width: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          // autogroupzgkhEUE (7wpycajqp78iSz7GNHzgKh)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 58*fem, 0*fem),
                          width: 185*fem,
                          height: 203*fem,
                          child: Stack(
                            children: [
                              Positioned(
                                // acehMYr (6:33)
                                left: 43*fem,
                                top: 67*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 100*fem,
                                    height: 49*fem,
                                    child: Text(
                                      'Aceh',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Inter',
                                        fontSize: 40*ffem,
                                        fontWeight: FontWeight.w600,
                                        height: 1.2125*ffem/fem,
                                        decoration: TextDecoration.underline,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // rectangle6T66 (6:34)
                                left: 0*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 185*fem,
                                    height: 91*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        color: Color(0xfffdce0f),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // aceh7gS (6:35)
                                left: 41*fem,
                                top: 21*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 100*fem,
                                    height: 49*fem,
                                    child: Text(
                                      'Aceh',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Inter',
                                        fontSize: 40*ffem,
                                        fontWeight: FontWeight.w600,
                                        height: 1.2125*ffem/fem,
                                        decoration: TextDecoration.underline,
                                        color: Color(0xffffffff),
                                        decorationColor: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // rectangle8oZG (6:37)
                                left: 4*fem,
                                top: 115*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 181*fem,
                                    height: 88*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        color: Color(0xfffdce0f),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // sumutvNz (6:69)
                                left: 32*fem,
                                top: 135*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 126*fem,
                                    height: 49*fem,
                                    child: Text(
                                      'Sumut',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Inter',
                                        fontSize: 40*ffem,
                                        fontWeight: FontWeight.w600,
                                        height: 1.2125*ffem/fem,
                                        decoration: TextDecoration.underline,
                                        color: Color(0xffffffff),
                                        decorationColor: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // autogroup5kqmcWi (7wpyp5QgyS2vKxZHmP5kqM)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 55*fem, 0*fem),
                          width: 184*fem,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Container(
                                // autogroupdhapLBp (7wpyvf44PgdrCaEZhNDHaP)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 27*fem),
                                width: 181*fem,
                                height: 88*fem,
                                decoration: BoxDecoration (
                                  color: Color(0xfffdce0f),
                                ),
                                child: Center(
                                  child: Text(
                                    'Jambi',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 40*ffem,
                                      fontWeight: FontWeight.w600,
                                      height: 1.2125*ffem/fem,
                                      decoration: TextDecoration.underline,
                                      color: Color(0xffffffff),
                                      decorationColor: Color(0xffffffff),
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                // autogroupnr7hPft (7wpyzKccsshtJjpvKJnr7h)
                                width: double.infinity,
                                height: 88*fem,
                                child: Stack(
                                  children: [
                                    Positioned(
                                      // rectangle13Lr2 (6:46)
                                      left: 3*fem,
                                      top: 0*fem,
                                      child: Align(
                                        child: SizedBox(
                                          width: 181*fem,
                                          height: 88*fem,
                                          child: Container(
                                            decoration: BoxDecoration (
                                              color: Color(0xfffdce0f),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      // bengkulu4GE (6:75)
                                      left: 0*fem,
                                      top: 20*fem,
                                      child: Align(
                                        child: SizedBox(
                                          width: 182*fem,
                                          height: 49*fem,
                                          child: Text(
                                            'Bengkulu',
                                            textAlign: TextAlign.center,
                                            style: SafeGoogleFont (
                                              'Inter',
                                              fontSize: 40*ffem,
                                              fontWeight: FontWeight.w600,
                                              height: 1.2125*ffem/fem,
                                              decoration: TextDecoration.underline,
                                              color: Color(0xffffffff),
                                              decorationColor: Color(0xffffffff),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // autogroupwnlwN22 (7wpz7jZw8iTe7UxTUjWNLw)
                          margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 34*fem, 0*fem),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // autogroupx6njVsL (7wpzE9Yuz3qCoGk5ZdX6nj)
                                margin: EdgeInsets.fromLTRB(6*fem, 0*fem, 0*fem, 17*fem),
                                width: 181*fem,
                                height: 88*fem,
                                decoration: BoxDecoration (
                                  color: Color(0xfffdce0f),
                                ),
                                child: Center(
                                  child: Text(
                                    'Jabar',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 40*ffem,
                                      fontWeight: FontWeight.w600,
                                      height: 1.2125*ffem/fem,
                                      decoration: TextDecoration.underline,
                                      color: Color(0xffffffff),
                                      decorationColor: Color(0xffffffff),
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                // autogroupjfawn5k (7wpzHPxW3wppwNcJZrJfaw)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 6*fem, 0*fem),
                                width: 181*fem,
                                height: 88*fem,
                                decoration: BoxDecoration (
                                  color: Color(0xfffdce0f),
                                ),
                                child: Center(
                                  child: Text(
                                    'Jateng',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 40*ffem,
                                      fontWeight: FontWeight.w600,
                                      height: 1.2125*ffem/fem,
                                      decoration: TextDecoration.underline,
                                      color: Color(0xffffffff),
                                      decorationColor: Color(0xffffffff),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // autogrouphoh9ete (7wpzP4TjM9fFHStVLrHoh9)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 30.5*fem, 0*fem),
                          width: 181*fem,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // autogroupwypqaXQ (7wpzV4HjnBxQ1Awyp2WYPq)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 27*fem),
                                width: double.infinity,
                                height: 88*fem,
                                decoration: BoxDecoration (
                                  color: Color(0xfffdce0f),
                                ),
                                child: Center(
                                  child: Text(
                                    'NTT',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 40*ffem,
                                      fontWeight: FontWeight.w600,
                                      height: 1.2125*ffem/fem,
                                      decoration: TextDecoration.underline,
                                      color: Color(0xffffffff),
                                      decorationColor: Color(0xffffffff),
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                // autogroupt6gfTr6 (7wpzZ91Ggg6r5QGU3gt6gF)
                                width: double.infinity,
                                height: 88*fem,
                                decoration: BoxDecoration (
                                  color: Color(0xfffdce0f),
                                ),
                                child: Center(
                                  child: Text(
                                    'Kalbar',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 40*ffem,
                                      fontWeight: FontWeight.w600,
                                      height: 1.2125*ffem/fem,
                                      decoration: TextDecoration.underline,
                                      color: Color(0xffffffff),
                                      decorationColor: Color(0xffffffff),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // autogroupodapxnr (7wpzg8ocXDnBv5fsbPodAP)
                          margin: EdgeInsets.fromLTRB(0*fem, 3*fem, 0*fem, 0*fem),
                          width: 187*fem,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // autogroupsnnshVY (7wpzmJKg7fvWhgH6q8SNNs)
                                margin: EdgeInsets.fromLTRB(3.5*fem, 0*fem, 2.5*fem, 24*fem),
                                width: double.infinity,
                                height: 88*fem,
                                decoration: BoxDecoration (
                                  color: Color(0xfffdce0f),
                                ),
                                child: Center(
                                  child: Text(
                                    'Sulteng',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 40*ffem,
                                      fontWeight: FontWeight.w600,
                                      height: 1.2125*ffem/fem,
                                      decoration: TextDecoration.underline,
                                      color: Color(0xffffffff),
                                      decorationColor: Color(0xffffffff),
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                // autogroupu8cwaZL (7wpzpoDr2wmBd1yobyu8cw)
                                width: double.infinity,
                                height: 98*fem,
                                child: Stack(
                                  children: [
                                    Positioned(
                                      // rectangle31urW (6:64)
                                      left: 3.5*fem,
                                      top: 0*fem,
                                      child: Align(
                                        child: SizedBox(
                                          width: 181*fem,
                                          height: 98*fem,
                                          child: Container(
                                            decoration: BoxDecoration (
                                              color: Color(0xfffdce0f),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      // gorontaloqEN (6:93)
                                      left: 0*fem,
                                      top: 21*fem,
                                      child: Align(
                                        child: SizedBox(
                                          width: 187*fem,
                                          height: 48*fem,
                                          child: Text(
                                            'Gorontalo',
                                            textAlign: TextAlign.center,
                                            style: SafeGoogleFont (
                                              'Inter',
                                              fontSize: 39*ffem,
                                              fontWeight: FontWeight.w600,
                                              height: 1.2125*ffem/fem,
                                              decoration: TextDecoration.underline,
                                              color: Color(0xffffffff),
                                              decorationColor: Color(0xffffffff),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupmd27iox (7wq1MHM3ttw2n7xDV8MD27)
                    margin: EdgeInsets.fromLTRB(4*fem, 0*fem, 2.5*fem, 11*fem),
                    width: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          // autogroupbqzhFot (7wq1dGtQP146hPSrjbbqZH)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 61*fem, 0*fem),
                          width: 181*fem,
                          height: 88*fem,
                          decoration: BoxDecoration (
                            color: Color(0xfffdce0f),
                          ),
                          child: Center(
                            child: Text(
                              'Sumbar',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'Inter',
                                fontSize: 40*ffem,
                                fontWeight: FontWeight.w600,
                                height: 1.2125*ffem/fem,
                                decoration: TextDecoration.underline,
                                color: Color(0xffffffff),
                                decorationColor: Color(0xffffffff),
                              ),
                            ),
                          ),
                        ),
                        Container(
                          // autogroupxnzkY2J (7wq1hSS8ZwpEN2iAtoXnzK)
                          margin: EdgeInsets.fromLTRB(0*fem, 2*fem, 61*fem, 0*fem),
                          width: 181*fem,
                          height: 100*fem,
                          child: Stack(
                            children: [
                              Positioned(
                                // rectangle14GDC (6:47)
                                left: 0*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 181*fem,
                                    height: 88*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        color: Color(0xfffdce0f),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // bangkabelitungaUn (6:76)
                                left: 10*fem,
                                top: 3*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 160*fem,
                                    height: 97*fem,
                                    child: Text(
                                      'Bangka Belitung',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Inter',
                                        fontSize: 40*ffem,
                                        fontWeight: FontWeight.w600,
                                        height: 1.2125*ffem/fem,
                                        decoration: TextDecoration.underline,
                                        color: Color(0xffffffff),
                                        decorationColor: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // autogroupvlkwGcW (7wq1nMTcK27WNPUvMuVLkw)
                          margin: EdgeInsets.fromLTRB(0*fem, 2*fem, 34*fem, 0*fem),
                          width: 181*fem,
                          height: 88*fem,
                          decoration: BoxDecoration (
                            color: Color(0xfffdce0f),
                          ),
                          child: Center(
                            child: Text(
                              'Jatim',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'Inter',
                                fontSize: 40*ffem,
                                fontWeight: FontWeight.w600,
                                height: 1.2125*ffem/fem,
                                decoration: TextDecoration.underline,
                                color: Color(0xffffffff),
                                decorationColor: Color(0xffffffff),
                              ),
                            ),
                          ),
                        ),
                        Container(
                          // autogroup4ujfk1t (7wq1r22AoDBYUZ5Gyr4uJF)
                          margin: EdgeInsets.fromLTRB(0*fem, 2*fem, 34*fem, 0*fem),
                          width: 181*fem,
                          height: 88*fem,
                          decoration: BoxDecoration (
                            color: Color(0xfffdce0f),
                          ),
                          child: Center(
                            child: Text(
                              'Kalteng',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'Inter',
                                fontSize: 40*ffem,
                                fontWeight: FontWeight.w600,
                                height: 1.2125*ffem/fem,
                                decoration: TextDecoration.underline,
                                color: Color(0xffffffff),
                                decorationColor: Color(0xffffffff),
                              ),
                            ),
                          ),
                        ),
                        Container(
                          // autogroup7f2xamc (7wq1vMEHZ5B3L2EEz97f2X)
                          width: 181*fem,
                          height: 88*fem,
                          decoration: BoxDecoration (
                            color: Color(0xfffdce0f),
                          ),
                          child: Center(
                            child: Text(
                              'Sulut',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'Inter',
                                fontSize: 40*ffem,
                                fontWeight: FontWeight.w600,
                                height: 1.2125*ffem/fem,
                                decoration: TextDecoration.underline,
                                color: Color(0xffffffff),
                                decorationColor: Color(0xffffffff),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupsw39fHG (7wq2AveLDNqWAGeqYMsW39)
                    margin: EdgeInsets.fromLTRB(4*fem, 0*fem, 2.5*fem, 26*fem),
                    width: double.infinity,
                    height: 101*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // autogrouprlnsmbC (7wq2RvDMHyaNxaoZiJRLns)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 61*fem, 13*fem),
                          width: 181*fem,
                          height: 88*fem,
                          decoration: BoxDecoration (
                            color: Color(0xfffdce0f),
                          ),
                          child: Center(
                            child: Text(
                              'Sumsel',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'Inter',
                                fontSize: 40*ffem,
                                fontWeight: FontWeight.w600,
                                height: 1.2125*ffem/fem,
                                decoration: TextDecoration.underline,
                                color: Color(0xffffffff),
                                decorationColor: Color(0xffffffff),
                              ),
                            ),
                          ),
                        ),
                        Container(
                          // autogroupntzvShL (7wq2WqEq33sexwaKBQNtZV)
                          margin: EdgeInsets.fromLTRB(0*fem, 7*fem, 59*fem, 6*fem),
                          width: 183*fem,
                          height: double.infinity,
                          child: Stack(
                            children: [
                              Positioned(
                                // rectangle15mUi (6:48)
                                left: 0*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 181*fem,
                                    height: 88*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        color: Color(0xfffdce0f),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // lampung6Wz (6:77)
                                left: 2*fem,
                                top: 23*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 181*fem,
                                    height: 49*fem,
                                    child: Text(
                                      'Lampung',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Inter',
                                        fontSize: 40*ffem,
                                        fontWeight: FontWeight.w600,
                                        height: 1.2125*ffem/fem,
                                        decoration: TextDecoration.underline,
                                        color: Color(0xffffffff),
                                        decorationColor: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // autogroupde2saBG (7wq2babvDCwZnUTQoRDe2s)
                          margin: EdgeInsets.fromLTRB(0*fem, 13*fem, 34*fem, 0*fem),
                          width: 181*fem,
                          height: 88*fem,
                          decoration: BoxDecoration (
                            color: Color(0xfffdce0f),
                          ),
                          child: Center(
                            child: Text(
                              'DIY',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'Inter',
                                fontSize: 40*ffem,
                                fontWeight: FontWeight.w600,
                                height: 1.2125*ffem/fem,
                                decoration: TextDecoration.underline,
                                color: Color(0xffffffff),
                                decorationColor: Color(0xffffffff),
                              ),
                            ),
                          ),
                        ),
                        Container(
                          // autogroupeorzdvE (7wq2fALHQwPvJE6wVpEoRZ)
                          margin: EdgeInsets.fromLTRB(0*fem, 13*fem, 34*fem, 0*fem),
                          width: 181*fem,
                          height: 88*fem,
                          decoration: BoxDecoration (
                            color: Color(0xfffdce0f),
                          ),
                          child: Center(
                            child: Text(
                              'Kalsel',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'Inter',
                                fontSize: 40*ffem,
                                fontWeight: FontWeight.w600,
                                height: 1.2125*ffem/fem,
                                decoration: TextDecoration.underline,
                                color: Color(0xffffffff),
                                decorationColor: Color(0xffffffff),
                              ),
                            ),
                          ),
                        ),
                        Container(
                          // autogroupvzqjfrv (7wq2j5PRkWK1BdXmtPVZQj)
                          margin: EdgeInsets.fromLTRB(0*fem, 7*fem, 0*fem, 6*fem),
                          width: 181*fem,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            color: Color(0xfffdce0f),
                          ),
                          child: Center(
                            child: Text(
                              'Sulbar',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'Inter',
                                fontSize: 40*ffem,
                                fontWeight: FontWeight.w600,
                                height: 1.2125*ffem/fem,
                                decoration: TextDecoration.underline,
                                color: Color(0xffffffff),
                                decorationColor: Color(0xffffffff),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogrouphrhq9GJ (7wq2wa2cKLbQBZKiN1HRhq)
                    margin: EdgeInsets.fromLTRB(4*fem, 0*fem, 2.5*fem, 24*fem),
                    width: double.infinity,
                    height: 88*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // autogroupqhqt59x (7wq39jM1kLR4oqLM9SqhQT)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 61*fem, 0*fem),
                          width: 181*fem,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            color: Color(0xfffdce0f),
                          ),
                          child: Center(
                            child: Text(
                              'Riau',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'Inter',
                                fontSize: 40*ffem,
                                fontWeight: FontWeight.w600,
                                height: 1.2125*ffem/fem,
                                decoration: TextDecoration.underline,
                                color: Color(0xffffffff),
                                decorationColor: Color(0xffffffff),
                              ),
                            ),
                          ),
                        ),
                        Container(
                          // autogroupdfgskG6 (7wq3Dp4YepZWt4eqP7DFgs)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 61*fem, 0*fem),
                          width: 181*fem,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            color: Color(0xfffdce0f),
                          ),
                          child: Center(
                            child: Text(
                              'Banten',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'Inter',
                                fontSize: 40*ffem,
                                fontWeight: FontWeight.w600,
                                height: 1.2125*ffem/fem,
                                decoration: TextDecoration.underline,
                                color: Color(0xffffffff),
                                decorationColor: Color(0xffffffff),
                              ),
                            ),
                          ),
                        ),
                        Container(
                          // autogroupg1vwcp6 (7wq3HJxia6QBoQMY9xg1vw)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 34*fem, 0*fem),
                          width: 181*fem,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            color: Color(0xfffdce0f),
                          ),
                          child: Center(
                            child: Text(
                              'Bali',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'Inter',
                                fontSize: 40*ffem,
                                fontWeight: FontWeight.w600,
                                height: 1.2125*ffem/fem,
                                decoration: TextDecoration.underline,
                                color: Color(0xffffffff),
                                decorationColor: Color(0xffffffff),
                              ),
                            ),
                          ),
                        ),
                        Container(
                          // autogroupap2phae (7wq3Lj2hCudB8L7R1GaP2P)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 34*fem, 0*fem),
                          width: 181*fem,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            color: Color(0xfffdce0f),
                          ),
                          child: Center(
                            child: Text(
                              'Kaltim',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'Inter',
                                fontSize: 40*ffem,
                                fontWeight: FontWeight.w600,
                                height: 1.2125*ffem/fem,
                                decoration: TextDecoration.underline,
                                color: Color(0xffffffff),
                                decorationColor: Color(0xffffffff),
                              ),
                            ),
                          ),
                        ),
                        Container(
                          // autogroup39gtnrz (7wq3QDvs8BTr3fp7n839GT)
                          width: 181*fem,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            color: Color(0xfffdce0f),
                          ),
                          child: Center(
                            child: Text(
                              'Maluku',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'Inter',
                                fontSize: 40*ffem,
                                fontWeight: FontWeight.w600,
                                height: 1.2125*ffem/fem,
                                decoration: TextDecoration.underline,
                                color: Color(0xffffffff),
                                decorationColor: Color(0xffffffff),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroup8dn7JKY (7wq3bibiHWN3veG9BD8Dn7)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2.5*fem, 0*fem),
                    height: 98*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          // autogroupzhbv2FY (7wq3oiFj9axMN6P87ZZhBV)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 65*fem, 0*fem),
                          width: 181*fem,
                          height: 88*fem,
                          decoration: BoxDecoration (
                            color: Color(0xfffdce0f),
                          ),
                          child: Center(
                            child: Text(
                              'Kep.Riau',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'Inter',
                                fontSize: 40*ffem,
                                fontWeight: FontWeight.w600,
                                height: 1.2125*ffem/fem,
                                decoration: TextDecoration.underline,
                                color: Color(0xffffffff),
                                decorationColor: Color(0xffffffff),
                              ),
                            ),
                          ),
                        ),
                        Container(
                          // autogroupnrkhHhG (7wq3si94mcV7quknRgNrKH)
                          width: 181*fem,
                          height: double.infinity,
                          child: Stack(
                            children: [
                              Positioned(
                                // rectangle17SKG (6:50)
                                left: 0*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 181*fem,
                                    height: 88*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        color: Color(0xfffdce0f),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // dkijakartawmp (6:79)
                                left: 17*fem,
                                top: 1*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 147*fem,
                                    height: 97*fem,
                                    child: Text(
                                      'DKI Jakarta',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Inter',
                                        fontSize: 40*ffem,
                                        fontWeight: FontWeight.w600,
                                        height: 1.2125*ffem/fem,
                                        decoration: TextDecoration.underline,
                                        color: Color(0xffffffff),
                                        decorationColor: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // autogroupd3uzr86 (7wq4CXw2uKXPwDPX4ed3uZ)
                          padding: EdgeInsets.fromLTRB(61*fem, 2*fem, 0*fem, 2*fem),
                          height: double.infinity,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                // autogroupz1cbn1k (7wq3x8BNow6JHnraMWz1CB)
                                width: 181*fem,
                                height: 88*fem,
                                decoration: BoxDecoration (
                                  color: Color(0xfffdce0f),
                                ),
                                child: Center(
                                  child: Text(
                                    'NTB',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 40*ffem,
                                      fontWeight: FontWeight.w600,
                                      height: 1.2125*ffem/fem,
                                      decoration: TextDecoration.underline,
                                      color: Color(0xffffffff),
                                      decorationColor: Color(0xffffffff),
                                    ),
                                  ),
                                ),
                              ),
                              SizedBox(
                                width: 34*fem,
                              ),
                              Container(
                                // autogroupembmr1c (7wq423EX9W1PBCHQk6EmBM)
                                width: 181*fem,
                                height: 88*fem,
                                decoration: BoxDecoration (
                                  color: Color(0xfffdce0f),
                                ),
                                child: Center(
                                  child: Text(
                                    'Sulsel',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 40*ffem,
                                      fontWeight: FontWeight.w600,
                                      height: 1.2125*ffem/fem,
                                      decoration: TextDecoration.underline,
                                      color: Color(0xffffffff),
                                      decorationColor: Color(0xffffffff),
                                    ),
                                  ),
                                ),
                              ),
                              SizedBox(
                                width: 34*fem,
                              ),
                              Container(
                                // autogroupcktmKvn (7wq467x43z9qFRbtykcKTm)
                                width: 181*fem,
                                height: 88*fem,
                                decoration: BoxDecoration (
                                  color: Color(0xfffdce0f),
                                ),
                                child: Center(
                                  child: Text(
                                    'Papua',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 40*ffem,
                                      fontWeight: FontWeight.w600,
                                      height: 1.2125*ffem/fem,
                                      decoration: TextDecoration.underline,
                                      color: Color(0xffffffff),
                                      decorationColor: Color(0xffffffff),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // macbookair3pce (1:6)
              width: double.infinity,
              height: 832*fem,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
              ),
              child: Stack(
                children: [
                  Positioned(
                    // rectangle36whG (7:8)
                    left: 0*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 1280*fem,
                        height: 815*fem,
                        child: Image.asset(
                          'assets/page-1/images/rectangle-36.png',
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // aceh1Tfc (7:11)
                    left: 61*fem,
                    top: 169*fem,
                    child: Align(
                      child: SizedBox(
                        width: 257*fem,
                        height: 125*fem,
                        child: Image.asset(
                          'assets/page-1/images/aceh-1.png',
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // aP3U (7:25)
                    left: 164*fem,
                    top: 393*fem,
                    child: Align(
                      child: SizedBox(
                        width: 51*fem,
                        height: 85*fem,
                        child: Text(
                          'A',
                          style: SafeGoogleFont (
                            'Inter',
                            fontSize: 70*ffem,
                            fontWeight: FontWeight.w600,
                            height: 1.2125*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // aGNA (7:24)
                    left: 164*fem,
                    top: 350*fem,
                    child: Align(
                      child: SizedBox(
                        width: 51*fem,
                        height: 85*fem,
                        child: Text(
                          'A',
                          style: SafeGoogleFont (
                            'Inter',
                            fontSize: 70*ffem,
                            fontWeight: FontWeight.w600,
                            height: 1.2125*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // nihadatutorialnyajugalohklikaj (7:12)
                    left: 19*fem,
                    top: 37*fem,
                    child: Align(
                      child: SizedBox(
                        width: 1227*fem,
                        height: 97*fem,
                        child: Text(
                          'Nih ada tutorialnya juga loh! Klik aja gambar makanan yang mau kamu buat',
                          style: SafeGoogleFont (
                            'Inter',
                            fontSize: 40*ffem,
                            fontWeight: FontWeight.w600,
                            height: 1.2125*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bikaambon1r5U (7:14)
                    left: 61*fem,
                    top: 355*fem,
                    child: Align(
                      child: SizedBox(
                        width: 257*fem,
                        height: 140*fem,
                        child: Image.asset(
                          'assets/page-1/images/bika-ambon-1.png',
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rendang1NZc (7:15)
                    left: 61*fem,
                    top: 556*fem,
                    child: Align(
                      child: SizedBox(
                        width: 257*fem,
                        height: 143*fem,
                        child: Image.asset(
                          'assets/page-1/images/rendang-1.png',
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // pempek15iv (7:16)
                    left: 421*fem,
                    top: 169*fem,
                    child: Align(
                      child: SizedBox(
                        width: 275*fem,
                        height: 125*fem,
                        child: Image.asset(
                          'assets/page-1/images/pempek-1.png',
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // keraktelor116n (7:18)
                    left: 421*fem,
                    top: 355*fem,
                    child: Align(
                      child: SizedBox(
                        width: 275*fem,
                        height: 140*fem,
                        child: Image.asset(
                          'assets/page-1/images/kerak-telor-1.png',
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // gudeg1imt (7:19)
                    left: 421*fem,
                    top: 556*fem,
                    child: Align(
                      child: SizedBox(
                        width: 275*fem,
                        height: 143*fem,
                        child: Image.asset(
                          'assets/page-1/images/gudeg-1.png',
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rujakcingur1FWv (7:20)
                    left: 762*fem,
                    top: 169*fem,
                    child: Align(
                      child: SizedBox(
                        width: 300*fem,
                        height: 168*fem,
                        child: Image.asset(
                          'assets/page-1/images/rujak-cingur-1.png',
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // sotobanjar1ZnW (7:21)
                    left: 762*fem,
                    top: 355*fem,
                    child: Align(
                      child: SizedBox(
                        width: 300*fem,
                        height: 140*fem,
                        child: Image.asset(
                          'assets/page-1/images/soto-banjar-1.png',
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // papeda1HiW (7:22)
                    left: 769*fem,
                    top: 556*fem,
                    child: Align(
                      child: SizedBox(
                        width: 286*fem,
                        height: 143*fem,
                        child: Image.asset(
                          'assets/page-1/images/papeda-1.png',
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // mailzcv (7:50)
                    left: 563.5762329102*fem,
                    top: 634.8647460938*fem,
                    child: Align(
                      child: SizedBox(
                        width: 24*fem,
                        height: 24*fem,
                        child: Image.asset(
                          'assets/page-1/images/mail.png',
                          width: 24*fem,
                          height: 24*fem,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // macbookair4tiJ (1:7)
              padding: EdgeInsets.fromLTRB(68*fem, 63*fem, 68*fem, 246*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                color: Color(0xfffdce0f),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    // contactusoqG (7:36)
                    margin: EdgeInsets.fromLTRB(4*fem, 0*fem, 0*fem, 34*fem),
                    child: Text(
                      'Contact Us\n',
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 70*ffem,
                        fontWeight: FontWeight.w600,
                        height: 1.2125*ffem/fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                  Container(
                    // autogroupm1xbKHp (7wq6CZS3CYXKSKAW3bm1xB)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 812*fem, 77*fem),
                    width: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Container(
                          // iconmapmarkerStE (7:42)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 23*fem, 3.34*fem),
                          width: 49*fem,
                          height: 58.66*fem,
                          child: Image.asset(
                            'assets/page-1/images/icon-map-marker.png',
                            width: 49*fem,
                            height: 58.66*fem,
                          ),
                        ),
                        Container(
                          // ourlocationjakartaindonesiaYwG (7:43)
                          constraints: BoxConstraints (
                            maxWidth: 260*fem,
                          ),
                          child: Text(
                            'OUR LOCATION\nJakarta,Indonesia',
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 30*ffem,
                              fontWeight: FontWeight.w600,
                              height: 1.2125*ffem/fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupjzd1U4E (7wq6JJmTnCyRNoPWk9JZD1)
                    margin: EdgeInsets.fromLTRB(10*fem, 0*fem, 761*fem, 20*fem),
                    width: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // iconinstagramfilliconD1p (8:4)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 35*fem, 0*fem),
                          width: 62*fem,
                          height: 64*fem,
                          child: Image.asset(
                            'assets/page-1/images/icon-instagram-fill-icon.png',
                            width: 62*fem,
                            height: 64*fem,
                          ),
                        ),
                        Container(
                          // lusciousnusantaraK4r (8:13)
                          margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 0*fem, 0*fem),
                          child: Text(
                            'luscious.nusantara',
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 30*ffem,
                              fontWeight: FontWeight.w600,
                              height: 1.2125*ffem/fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupnugsq3C (7wq6PPTL6CW4Zz3v4LNuGs)
                    margin: EdgeInsets.fromLTRB(10*fem, 0*fem, 731*fem, 20*fem),
                    width: double.infinity,
                    height: 80*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // iconemailoutlineZUz (8:8)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 29*fem, 0*fem),
                          padding: EdgeInsets.fromLTRB(5.67*fem, 13.33*fem, 5.67*fem, 13.33*fem),
                          height: double.infinity,
                          decoration: BoxDecoration (
                            color: Color(0x00fdce0f),
                          ),
                          child: Center(
                            // vectorUM4 (8:7)
                            child: SizedBox(
                              width: 56.67*fem,
                              height: 53.33*fem,
                              child: Image.asset(
                                'assets/page-1/images/vector.png',
                                width: 56.67*fem,
                                height: 53.33*fem,
                              ),
                            ),
                          ),
                        ),
                        Container(
                          // lusciousnusantaraCXx (8:14)
                          margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 0*fem, 0*fem),
                          child: Text(
                            '@luscious.nusantara',
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 30*ffem,
                              fontWeight: FontWeight.w600,
                              height: 1.2125*ffem/fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupff5q7up (7wq6UtJApV77jESSzFFF5q)
                    margin: EdgeInsets.fromLTRB(16*fem, 0*fem, 731*fem, 0*fem),
                    width: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // iconalternatephoneEDk (8:11)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 29*fem, 0*fem),
                          width: 62*fem,
                          height: 70*fem,
                          child: Image.asset(
                            'assets/page-1/images/icon-alternate-phone.png',
                            width: 62*fem,
                            height: 70*fem,
                          ),
                        ),
                        Container(
                          // YES (8:15)
                          margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 0*fem, 0*fem),
                          child: Text(
                            '+62-812-3456-7890',
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 30*ffem,
                              fontWeight: FontWeight.w600,
                              height: 1.2125*ffem/fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}